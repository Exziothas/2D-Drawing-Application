/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkg2d.drawing.application;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Point;
import java.awt.Stroke;
/**
 *
 * @author Chen
 */
public abstract class MyBoundedShapes extends MyShapes{
    private boolean filled;
    
    public MyBoundedShapes (Point pntA, Point pntB, Paint paint, Stroke strk, boolean filled)
    {super(pntA,pntB,paint,strk);
    this.filled = filled;}

    public boolean isFilled() {
        return filled;
    }

    public void setFilled(boolean filled) {
        this.filled = filled;
    }

    public int getTopLeftX()
    {return Math.min((int)(getStartPoint().getX()),(int)(getEndPoint().getX()));}
    
    public int getTopLeftY()
    {return Math.min((int)(getStartPoint().getY()),(int)(getEndPoint().getY()));}
    
    public int getWidth()
    {return Math.abs((int)(getStartPoint().getX())-(int)(getEndPoint().getX()));}
    
    public int getHeight()
    {return Math.abs((int)(getStartPoint().getY())-(int)(getEndPoint().getY()));}
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkg2d.drawing.application;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Point;
import java.awt.Stroke;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JSpinner;

/**
 *
 *
 * @author Chen
 */
/*
        a) a combo box for selecting the shape to draw, a line, oval, or rectangle.
b) two JButtons that each show a JColorChooser dialog to allow the user to choose the first and second color in the gradient.
c) an Undo button to Undo the last shape drawn.
d) a Clear button to Clear all shapes from the drawing.
e) a checkbox which specifies if the shape should be filled or unfilled.
f) a checkbox to specify whether to paint using a gradient.
g) a checkbox for specifying whether to draw a dashed or solid line.
h) a JSpinner for entering the Stroke width.
i) a JSpinner for entering the Stroke dash length.
j) a JPanel on which the shapes are drawn.
k) a status bar JLabel at the bottom of the frame that displays the current location of the mouse on the draw panel.
 */

 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
public class DrawingApplicationFrame extends JFrame {

    // Create the panels for the top of the application. One panel for each
    // line and one to contain both of those panels.
    private final JPanel Jpanel1;
    private final JPanel Jpanel2;
    private final JPanel TopPanel;
    // create the widgets for the firstLine Panel.
    private final JComboBox<String> ComboBox;
    private final JLabel ComboLabel;
    private final JButton ColorButton1;
    private final JButton ColorButton2;
    private final JButton Undo;
    private final JButton Clear;
    //create the widgets for the secondLine Panel.
    private final JLabel OptionsLabel;
    private final JLabel widthLabel;
    private final JLabel DashLabel;
    private final JCheckBox FilledBox;
    private final JCheckBox GradientBox;
    private final JCheckBox DashedBox;
    private final JSpinner LineWidth;
    private final JSpinner DashLength;
    // Variables for drawPanel.
    private final DrawPanel drawPanel;
    private Color Color1;
    private Color Color2;
    private Stroke Stroke;
    private static final String[] shape = {"Rectangle", "Line", "Oval"};
    private static ArrayList<MyShapes> s = new ArrayList<>();

    // add status label
    private final JLabel StatusLabel;

    // Constructor for DrawingApplicationFrame
    public DrawingApplicationFrame() {

        // add widgets to panels
        // firstLine widgets
        ComboLabel = new JLabel("Shapes: ");
        ComboBox = new JComboBox<String>(shape);
        ComboBox.setMaximumRowCount(3);

        ColorButton1 = new JButton("1st Color");
        ColorButton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
                Color1 = JColorChooser.showDialog(DrawingApplicationFrame.this, "Choose a color", Color1);
            }
        });
        ColorButton2 = new JButton("2nd Color");
        ColorButton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
                Color2 = JColorChooser.showDialog(DrawingApplicationFrame.this, "Choose a color", Color2);

            }
        });

        Undo = new JButton("Undo");
        Undo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
                if (s.size() > 0) {
                    s.remove(s.size() - 1);
                    repaint();
                }
            }
        });

        Clear = new JButton("Clear");
        Clear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
                s.clear();
                repaint();
            }
        });
        // secondLine widgets
        OptionsLabel = new JLabel("Options: ");

        FilledBox = new JCheckBox("Filled");
        GradientBox = new JCheckBox("Use Gradient");
        DashedBox = new JCheckBox("Dashed");

        widthLabel = new JLabel("Line Width: ");
        LineWidth = new JSpinner();
        LineWidth.setValue(10);

        DashLabel = new JLabel("Dash Length: ");
        DashLength = new JSpinner();
        DashLength.setValue(10);
        // add top panel of two panels
        // add TopPanel to North, drawPanel to Center, and StatusLabel to South
        TopPanel = new JPanel();
        TopPanel.setLayout(new GridLayout(2, 1));

        Jpanel1 = new JPanel();
        Jpanel1.add(ComboLabel);
        Jpanel1.add(ComboBox);
        Jpanel1.add(ColorButton1);
        Jpanel1.add(ColorButton2);
        Jpanel1.add(Undo);
        Jpanel1.add(Clear);
        Jpanel1.setBackground(Color.CYAN);

        Jpanel2 = new JPanel();
        Jpanel2.add(OptionsLabel);
        Jpanel2.add(FilledBox);
        Jpanel2.add(GradientBox);
        Jpanel2.add(DashedBox);
        Jpanel2.add(widthLabel);
        Jpanel2.add(LineWidth);
        Jpanel2.add(DashLabel);
        Jpanel2.add(DashLength);
        Jpanel2.setBackground(Color.CYAN);

        TopPanel.add(Jpanel1);
        TopPanel.add(Jpanel2);

        // add TopPanel to North, drawPanel to Center, and StatusLabel to South
        add(TopPanel, BorderLayout.NORTH);

        drawPanel = new DrawPanel();
        add(drawPanel, BorderLayout.CENTER);

        StatusLabel = new JLabel();
        add(StatusLabel, BorderLayout.SOUTH);

    }

    // Create event handlers, if needed
    // Create a private inner class for the DrawPanel.
    private class DrawPanel extends JPanel {

        public DrawPanel() {

            MouseHandler handler = new MouseHandler();
            addMouseMotionListener(handler);
            addMouseListener(handler);
        }

        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;

            //loop through and draw each shape in the shapes arraylist
            for (MyShapes shape : s) {
                shape.draw(g2d);
            }
        }

        private class MouseHandler extends MouseAdapter implements MouseMotionListener {

            public void mousePressed(MouseEvent event) {

                Paint paint = Color1;
                float[] dA = {(float) (int) DashLength.getValue()};
                
                if (GradientBox.isSelected()) {
                    paint = new GradientPaint(0, 0, Color1, 50, 50, Color2, true);
                }
                if (DashedBox.isSelected()) {
                    Stroke = new BasicStroke((int) LineWidth.getValue(), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 10, dA, 0);
                } else {
                    Stroke = new BasicStroke((int) LineWidth.getValue(), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
                }

                if (ComboBox.getSelectedItem() == "Rectangle") {
                    MyRectangle rect = new MyRectangle(event.getPoint(), event.getPoint(), paint, Stroke, FilledBox.isSelected());
                    s.add(rect);
                } else if (ComboBox.getSelectedItem() == "Line") {
                    MyLine l = new MyLine(event.getPoint(), event.getPoint(), paint, Stroke);
                    s.add(l);
                } else {
                    MyOval oval = new MyOval(event.getPoint(), event.getPoint(), paint, Stroke, FilledBox.isSelected());
                    s.add(oval);
                }
                repaint();
            }

            public void mouseReleased(MouseEvent event) {

                s.get(s.size() - 1).setEndPoint(event.getPoint());
                repaint();
            }

            @Override
            public void mouseDragged(MouseEvent event) {

                s.get(s.size() - 1).setEndPoint(event.getPoint());
                repaint();
            }

            @Override
            public void mouseMoved(MouseEvent event) {
                StatusLabel.setText(String.format("(%d, %d)", event.getX(), event.getY()));
            }
        }

    }
}
